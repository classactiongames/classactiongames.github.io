CLASS ACTION GAMES - STUDIO LOGOS

svg/  every logo as SVG (scales to any size)
png/  the same logos as transparent PNG; the number is the width or the size in pixels

Variants: no suffix = colour, for light backgrounds; -on-dark = colour, for dark
backgrounds; -1c-black and -1c-white = one colour.

Which one:
  lockup-h          the horizontal logo, 64 px tall and up
  lockup-compact    one line, for small spaces (20 to 63 px tall)
  lockup-stacked    for square spaces, 160 px tall and up
  seal              the full seal, 128 px and up
  mark              the seal without its ring text, 49 to 127 px
  bold              the solid round mark, 48 px and down (and avatars)
  wordmark          the name without the seal

Please leave clear space around the logo (the height of the capital letters on
every side of a lockup; an eighth of the width around a mark). Do not stretch,
recolour, tilt or add effects to the logos, and do not retype the wordmark.

Colours: paper #f6f0e1, ink #1d1b22, stamp red #b0281f, night red #c8352b.
